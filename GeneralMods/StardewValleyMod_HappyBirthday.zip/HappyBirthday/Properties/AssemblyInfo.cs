﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("HappyBirthday")]
[assembly: Guid("a7a4b67b-3cd7-421f-a4a7-2d656f0ab4d9")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
